#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>// for execv and fork
#include <sys/types.h>
#include <sys/wait.h>//
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>  
#include "smallsh_functions.h"



struct cmd_var* read_commandline(char* lines){

char *savepointer;
bool temp = false;
char *token;
int i = 0;

struct cmd_var* commandline = malloc(sizeof(struct cmd_var));
commandline->background = false;

//check edge case when the user wants to press enter with no input
    if (strcmp(lines, "") == 0) {
        commandline->argv[0] = strdup(""); //
        //strcpy(commandline->argv[0],"");
        return commandline;
    }


   for (token = strtok_r(lines, " ", &savepointer);
      token != NULL;
      token = strtok_r(NULL, " ", &savepointer)){

      if(strcmp("&", token)==0){
       //token = strtok_r(NULL, " ", &savepointer);
        commandline->background = true;
        //printf("hello\n");
      }

   	  if(strcmp("<",token) == 0){ //input file
          // take care of the redirection
       	//	   	     printf("print first : %s\n", token);
       	token = strtok_r(NULL, " ", &savepointer);
        commandline->input_cmd = malloc(strlen(token)+1 * sizeof(char));
        strcpy(commandline->input_cmd, token);
        temp = true;
       }
       else if(strcmp(">",token) == 0){
          // take care of the redirection
       //		   	     printf(" print second :%s\n", token);
       		token = strtok_r(NULL, " ", &savepointer);
          commandline->output_cmd = malloc(strlen(token)+1 * sizeof(char));
          strcpy(commandline->output_cmd, token); //output file
          temp = true;
		    }

       // printf("test>>>>%s\n",token );
        //delete the file commands from the argv
        if(temp != true){
          commandline->argv[i] = malloc(strlen(token)+1 * sizeof(char));
          strcpy(commandline->argv[i], token);
       	  i++;
        }

  }

   commandline->num_arg = i;
   int counter = 0;
   int dollar_counter = 0;
 
   bool status = false;
   int process_num = getpid();
   char str[60];
   int length_num = sprintf(str, "%d", process_num);

   //printf("process ID:  %d \n", process_num);

   if(strcmp(commandline->argv[0], "mkdir") == 0){
    //printf("(string compare if statement)\n" );
     if(commandline->argv[1] != NULL){
      printf("NULL if statement)\n" );

      if(strstr(commandline->argv[1], "$$") != NULL){
        printf("str str if statement\n");
        
       // for (int j = 0; j < strlen(commandline->argv[1]) + length_num; j++){
         // for(int z = 0; z < length_num; z++){}
           // if(commandline->argv[1][j] == '$'){counter++;}
            //if(counter % 2 == 0){status = true;}
            //if(status && j != 0){
              //for(int z = 0; z < length_num; z++){
              //status = true;
              //   if(dollar_counter < length_num){
              //   commandline->argv[1][j-1] = str[dollar_counter];
              //   dollar_counter++;
              // }
              // else if(dollar_counter > length_num){
              //   dollar_counter = 0;
              //   status = false;
              // }
            //}
          }
        }
      }

// printf("directory name is: %s\n", commandline->argv[1]);
// for (int i = 0; i < sizeof(commandline->argv[1]); ++i){
//   printf("%c\n",commandline->argv[1][i]);
// }

     //  for(int j = 0; j < strlen(commandline->argv[1]); j++){
     //    if(commandline->argv[1][j] == '$'){counter++;}
     //    if(counter % 2 == 1){dollar_counter++;}
     //  }

     // if(dollar_counter == 2){
          
     //    for(int j = 0; j < strlen(commandline->argv[1]); j++){

     //      commandline->argv[1][j] == '$'
     //    }

     //  }


    // }
  //}

  return commandline;

}



//***************NEEED TO IMPLEMENT THE $$

//referenced module: Processes and I/O
/**
stdin: File descriptor is 0. Defaults to reading from the terminal.
stdout: File descriptor is 1. Defaults to writing to the terminal.
stderr: File descriptor is 2. Defaults to writing to the terminal.
*/
void input_file(char* input_cmd){

  char file_name[250];
  strcpy(file_name, input_cmd);
  int filedescriptor = open(file_name, O_RDONLY );

  if(filedescriptor == -1){
    printf("Unable to open \"%s\"\n", file_name);
      fflush(stdout);
    exit(1);
  }


  //printf("filedescriptor before dup2 == %d\n", filedescriptor); 
 //fflush(stdout);
  //redirect the stdin to the input file
  int stdin_value = dup2(filedescriptor, 0);   //reading from the file now
  if(stdin_value == -1){
    perror("input dup2()");
  }

//can use int access(const char *pathname, int mode);
  /*    modes:

F_OK flag : Used to check for existence of file.
R_OK flag : Used to check for read permission bit.
W_OK flag : Used to check for write permission bit.
X_OK flag : Used to check for execute permission bit.
  */

} 

void output_file(char* output_cmd){

  char file_name[250];
  strcpy(file_name, output_cmd);
  int filedescriptor = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0640);

  if(filedescriptor == -1){
   // printf("Unable to open \"%s\"\n", file_name);
    perror("Unable to open");
    printf("\"%s\"\n", file_name);
    fflush(stdout);
    exit(1);
  }


  //printf("filedescriptor before dup2 for output== %d\n", filedescriptor); 
  //fflush(stdout);
  //redirect the stdin to the input file
  int stdin_value = dup2(filedescriptor, 1);   //writing to the file
  if(stdin_value == -1){
    perror("output dup2()");
  }


} 




// char * read_commandline(void)
// {
//   char *line = NULL;
//   ssize_t bufsize = 0; // have getline allocate a buffer for us

//   if (getline(&line, &bufsize, stdin) == -1){
//     if (feof(stdin)) {
//       exit(EXIT_SUCCESS);  // We recieved an EOF
//     } 
//     else  {
//       perror("readline");
//       exit(EXIT_FAILURE);
//     }
//   }

//   return line;
// }