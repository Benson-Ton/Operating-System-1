/*
 Benson Ton
 5/16/22

Work Cited:
*Check substring exist in C from Stackoverflow
https://stackoverflow.com/questions/12784766/check-substring-exists-in-a-string-in-c

*Example code provided from class
https://replit.com/@cs344/65prodconspipelinec#main.c

*Exploration: Condition Variables
https://canvas.oregonstate.edu/courses/1883362/pages/exploration-condition-variables?module_item_id=21941927


*Exploration: Concurrency
https://canvas.oregonstate.edu/courses/1883362/pages/exploration-concurrency?module_item_id=21941923

*Exploration: Threads - Concepts & API
https://canvas.oregonstate.edu/courses/1883362/pages/exploration-threads-concepts-and-api?module_item_id=21941924

*Exploration: Synchronization for Concurrent Execution
https://canvas.oregonstate.edu/courses/1883362/pages/exploration-synchronization-for-concurrent-execution?module_item_id=21941925

*Exploration: Synchronization Mechanisms Beyond Mutex
https://canvas.oregonstate.edu/courses/1883362/pages/exploration-synchronization-mechanisms-beyond-mutex?module_item_id=21941926
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <string.h>
#include <pthread.h>
#include <stdbool.h>
#include <math.h>
#include "functions.h"

//size of the buffers
/*requirements: 
*	no more than 49 lines before stop 
*	no more than 1000 characters
*/ 
#define MAX_CHAR 1000
#define MAX_LINES 49
#define MAX_OUTPUT_CHAR 80



// char text_buf[MAX_CHAR]; //input buffer
// char sep_buf[MAX_CHAR]; //after line seperator
// char plus_sign_buf[MAX_CHAR]; // after ++ are replaced
char text_buf[MAX_LINES][MAX_CHAR]; //input buffer
char sep_buf[MAX_LINES][MAX_CHAR]; //after line seperator
char plus_sign_buf[MAX_LINES][MAX_CHAR]; // after ++ are replaced
//char output_buf[MAX_OUTPUT_CHAR];

//boolean checkers
bool stop_process = false;
bool stop_input = false;

char* halt;

//index buffer trackers
//int index_input_buf = 0;



//CITED: https://replit.com/@cs344/65prodconspipelinec
//PIPELINE of producers and consumers consist of 3 threads example code
//intialize mutexes
pthread_mutex_t mutex_1, mutex_2, mutex_3 = PTHREAD_MUTEX_INITIALIZER;


/* for the first the first shared buffer */
// Number of items in the buffer
int count_1 = 0;
// Index where the input thread will put the next item
int prod_idx_1 = 0;
// Index where the square-root thread will pick up the next item
int con_idx_1 = 0;

char* test1;

pthread_cond_t full_1 = PTHREAD_COND_INITIALIZER;



/* for the first the first shared buffer */
// Number of items in the buffer
int count_2 = 0;
// Index where the input thread will put the next item
int prod_idx_2 = 0;
// Index where the square-root thread will pick up the next item
int con_idx_2 = 0;

pthread_cond_t full_2 = PTHREAD_COND_INITIALIZER;


//attempting a unbounded buffer


/* for the first the first shared buffer */
// Number of items in the buffer
int count_3 = 0;
// Index where the input thread will put the next item
int prod_idx_3 = 0;
// Index where the square-root thread will pick up the next item
int con_idx_3 = 0;

pthread_cond_t full_3 = PTHREAD_COND_INITIALIZER;





void put_buff_1(char* item){
  // Lock the mutex before putting the item in the buffer
  pthread_mutex_lock(&mutex_1);
  // Put the item in the buffer
	strcpy(text_buf[prod_idx_1],item);
  // Increment the index where the next item will be put.
  prod_idx_1 = prod_idx_1 + 1;
  count_1++;
  // Signal to the consumer that the buffer is no longer empty
  pthread_cond_signal(&full_1);
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_1);

//printf("text_buf %s\n", text_buf);
}



//input thread functions 
//then checks whether the ascii values are within the boundaries
void *input_thread(void *args)
{
	char temp_buf[MAX_CHAR];
while(stop_input != true){
		fgets(temp_buf, sizeof(temp_buf), stdin);
		//exit out of the loop if it ecounters 'STOP'
	if(strcmp("STOP\n",temp_buf) == 0){
		//stop_input = true;
		//printf("STOP PROCESS CONDITON HAS MET INPUT\n");
		put_buff_1(temp_buf);
		//halt = strdup("STOP\n");
		//printf("FINAL;%s\n",text_buf );
		//return NULL;
		break;
	}
	put_buff_1(temp_buf);

}
return NULL;
}


char* get_buff_1(){


  // Lock the mutex before checking if the buffer has data
  pthread_mutex_lock(&mutex_1);
  while (count_1 == 0)
    // Buffer is empty. Wait for the producer to signal that the buffer has data
    pthread_cond_wait(&full_1, &mutex_1);
//  char item = text_buf[con_idx_1];

	char* temp_c =  calloc(1000,sizeof(char));
	strcpy(temp_c,text_buf[con_idx_1]);

  // Increment the index from which the item will be picked up
  con_idx_1 = con_idx_1 + 1;
  count_1--;
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_1);
  // Return the item
  return temp_c;
}

void put_buff_2(char* item){
  // Lock the mutex before putting the item in the buffer
  pthread_mutex_lock(&mutex_2);
 
  // Put the item in the buffer
	strcpy(sep_buf[prod_idx_2], item);
  
  // Increment the index where the next item will be put.
  prod_idx_2 = prod_idx_2 + 1;
  count_2++;
  // Signal to the consumer that the buffer is no longer empty
  pthread_cond_signal(&full_2);
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_2);
}

//separates the line 
//if not then dont store in buffer
void *line_seperator_thread(void *args)
{

while(stop_input != true){
//char terminate_process[10] = "STOP";
char *temp_c =  calloc(1000, sizeof(char*));

	temp_c = get_buff_1();


	if(strcmp("STOP\n",temp_c) == 0){
		stop_input = true;
	//	printf("STOP PROCESS CONDITON HAS MET LINE\n");
		//return NULL;
		break;
	}

	for(int i = 0; i < strlen(temp_c); i++){
		if(temp_c[i] == '\n'){temp_c[i] = ' ';}
	}
	put_buff_2(temp_c);
}
   //strcpy(sep_buf, text_buf);
return NULL;
}



char* get_buff_2(){

  // Lock the mutex before checking if the buffer has data
  pthread_mutex_lock(&mutex_2);
  while (count_2 == 0)
    // Buffer is empty. Wait for the producer to signal that the buffer has data
    pthread_cond_wait(&full_2, &mutex_2);

	char* temp_c =  calloc(1000,sizeof(char));
	strcpy(temp_c,sep_buf[con_idx_2]);

  // Increment the index from which the item will be picked up
  con_idx_2 = con_idx_2 + 1;
  count_2--;
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_2);
  // Return the item
  return temp_c;
}

void put_buff_3(char* item){
  // Lock the mutex before putting the item in the buffer
  pthread_mutex_lock(&mutex_3);
 
  // Put the item in the buffer
  strcpy(plus_sign_buf[prod_idx_3],item);
  
  // Increment the index where the next item will be put.
  prod_idx_3 = prod_idx_3 + 1;
  count_3++;
  // Signal to the consumer that the buffer is no longer empty
  pthread_cond_signal(&full_3);
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_3);
}

void *plus_sign_thread(void *args)
{

while(stop_input != true){
	char *temp_c =  calloc(1000, sizeof(char*));
	char* edited_string;
	temp_c = get_buff_2();

		if(strcmp("STOP\n",temp_c) == 0){
		stop_input = true;
		//printf("STOP PROCESS CONDITON HAS MET PLUS\n");
		//return NULL;
		break;
	}
	edited_string = replaceplus(temp_c,"++","^");
	//edited_string = replaceplus(sep_buf, "++", "^");
	//strcpy(plus_sign_buf,edited_string);
	//printf("IN PLUS %s\n", edited_string);
	put_buff_3(edited_string);

	free(edited_string);

}
return NULL;
}

char* get_buff_3(){

  // Lock the mutex before checking if the buffer has data
  pthread_mutex_lock(&mutex_3);
  while (count_3 == 0)
    // Buffer is empty. Wait for the producer to signal that the buffer has data
    pthread_cond_wait(&full_3, &mutex_3);
//  char item = text_buf[con_idx_1];

	char* temp_c =  calloc(1000,sizeof(char));
	strcpy(temp_c,plus_sign_buf[con_idx_3]);
//printf("get_buff_3: %s", temp_c);
  // Increment the index from which the item will be picked up
  con_idx_3 = con_idx_3 + 1;
  count_3--;
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_3);
  // Return the item
  return temp_c;
}

void *output_thread(void *args)
{

while(stop_input != true){

	char *temp_c = calloc(1000,sizeof(char));
	temp_c = get_buff_3();

	if(strcmp("STOP\n",temp_c) == 0){
		stop_input = true;
		//printf("STOP PROCESS CONDITON HAS MET OUT\n");
		//return NULL;
		break;
	}

	int counter = 0;
	int operation, length;
	//printf("OUT_THREAD %s\n", temp_c);
	length = strlen(plus_sign_buf);
   // printf("Number of rows: %d\n", LEN(plus_sign_buf));
   //  printf("Number of columns: %d\n", LEN(plus_sign_buf[0]));
	//printf("Total %d \n",sizeof(plus_sign_buf) );
	//printf("Number of columns: %d\n", sizeof(plus_sign_buf[0]));
   // int row = total / column;
    //printf("Number of rows: %d\n", sizeof(plus_sign_buf)/sizeof(plus_sign_buf[0]));
	operation = length/80;

//printf("DIVIDED: %d \n",operation );


//will print the 80 characters as a line before the STOP process
	for (int i = 0; i < operation; i++)
	{
		for(int j = 0; j < 80; j++){

			printf("%c",temp_c[counter] );
			counter++;
		}
	
		printf("\n");
	}

}
	return NULL;

}



int main(int argc, char const *argv[])
{
	
	pthread_t input_t, line_sep_t, plus_sign_t,output_t;

//Exploration: Synchronization for Concurrent Execution
//https://canvas.oregonstate.edu/courses/1883362/pages/exploration-synchronization-for-concurrent-execution?module_item_id=21941925   
    pthread_create(&input_t, NULL, input_thread, NULL);
    pthread_create(&line_sep_t, NULL, line_seperator_thread, NULL);
    pthread_create(&plus_sign_t, NULL, plus_sign_thread, NULL);
    pthread_create(&output_t, NULL, output_thread, NULL);


//Exploration: Synchronization Mechanisms Beyond Mutex
//https://canvas.oregonstate.edu/courses/1883362/pages/exploration-synchronization-mechanisms-beyond-mutex?module_item_id=21941926
    // Wait for the threads to terminate
    pthread_join(input_t, NULL);
    pthread_join(line_sep_t, NULL);
    pthread_join(plus_sign_t, NULL);
    pthread_join(output_t, NULL);


    //need to destroy mutex
    pthread_mutex_destroy(&mutex_1);
    pthread_mutex_destroy(&mutex_2);
    pthread_mutex_destroy(&mutex_3);

    // terminates the calling thread of our four threads
    pthread_exit(&input_thread);
    pthread_exit(&line_seperator_thread);
    pthread_exit(&plus_sign_thread);
    pthread_exit(&output_thread);



	return 0;
}
