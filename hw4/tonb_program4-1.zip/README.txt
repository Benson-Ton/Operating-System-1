small shell assignment 3

Compiling instructions:

1) Run make file by using "make" in the command line

2) Then there should be a executable as "line_processor" 

with files:

./line_processor < input1.txt 


without gradescripts:

./line_processor
