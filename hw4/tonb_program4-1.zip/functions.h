#ifndef functions_h
#define functions_h


char* replaceplus(const char* buf, const char* plus, const char* replacewith);

#endif














