Compiling instructions:

Run make file by using "make" in the command line

Then run program with ./movies_by_year 